﻿Place any addition visual studio project templates in this folder.
- Files with an .xml extension will be scanned and listed as options in TLCGen
- Files ending in _filters.xml (if present) will not be listed in the TLCGen, 
  but will be used for generating the .filters file for a project