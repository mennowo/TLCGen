#ifndef TGKVAR_H
#define TGKVAR_H
#include "sysdef.c"

extern mulv TGK_max[FCMAX][FCMAX];
extern mulv TGK_max_old[FCMAX][FCMAX];
extern mulv TGK_timer[FCMAX];
extern bool TGK[FCMAX][FCMAX];
extern mulv GKC[FCMAX];

#endif


