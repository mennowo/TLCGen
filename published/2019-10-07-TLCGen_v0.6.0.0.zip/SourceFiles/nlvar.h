#ifndef __NLVAR
#define __NLVAR

#include "sysdef.c"

extern mulv TNL_PAR[FCMAX];
extern mulv TNL_max[FCMAX];
extern bool TNL[FCMAX];
extern mulv TNL_timer[FCMAX];

#endif // __NLVAR
