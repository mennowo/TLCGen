#include "gkvar.h"

mulv TGK_max[FCMAX][FCMAX];
mulv TGK_max_old[FCMAX][FCMAX];
mulv TGK_timer[FCMAX];
bool TGK[FCMAX][FCMAX];
mulv GKC[FCMAX];
